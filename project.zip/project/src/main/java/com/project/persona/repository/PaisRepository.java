package com.project.persona.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.persona.model.Pais;

public interface PaisRepository extends JpaRepository<Pais, Long>{

}