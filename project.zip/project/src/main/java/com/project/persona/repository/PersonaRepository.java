package com.project.persona.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.persona.model.Persona;

public interface PersonaRepository extends JpaRepository<Persona, Long>{

}